/*export const data = [
    {
        "imageId": "a75aa830-fae3-49fa-937b-b2b50ceebb2b",
        "imageName": "Screenshot 2021-07-14 174006.jpg",
        "image": null,
        "imageTag": "image/jpeg",
        "userId": {
            "email": "test1@gmail.com",
            "password": null,
            "username": "user20",
            "mobileNumber": null,
            "active": false,
            "role": null
        },
        "comments": [
            {
                "commentId": "d5069347-feee-493a-bc7f-5c9c2cdc1968",
                "comment": "The image is really nice",
                "userId": {
                    "email": "test1@gmail.com",
                    "password": null,
                    "username": "user2",
                    "mobileNumber": null,
                    "active": false,
                    "role": null
                }
            },
            {
                "commentId": "d5069347-feee-493a-bc7f-5c9c2cdc1969",
                "comment": "The image is really nice image",
                "userId": {
                    "email": "test1@gmail.com",
                    "password": null,
                    "username": "Prabhath",
                    "mobileNumber": null,
                    "active": false,
                    "role": null
                }
            }
        ]
    },
    {
        "imageId": "48d47afe-5614-499b-a3da-d0078d1b1ee9",
        "imageName": "Screenshot 2021-07-26 210541.jpg",
        "image": null,
        "imageTag": "image/jpeg",
        "userId": {
            "email": "test2@gmail.com",
            "password": null,
            "username": "user2",
            "mobileNumber": null,
            "active": false,
            "role": null
        },
        "comments": [
            {
                "commentId": "d5069347-feee-493a-bc7f-5c9c2cdc1969",
                "comment": "The image is really nice image",
                "userId": {
                    "email": "test1@gmail.com",
                    "password": null,
                    "username": "Prabhath",
                    "mobileNumber": null,
                    "active": false,
                    "role": null
                }
            }
        ]
    }
]*/