export const columns = [
  { field: "id", headerName: "S. No", width: 70, align: "center" },
  { field: "username", headerName: "Name", width: 200 },
  { field: "role", headerName: "Role", width: 250 },
];
export const usersdata = [
  { id: 1, username: "Snow", role: "user", email: "Jon@gmail.com" },
  { id: 2, username: "Lannister", role: "user", email: "Cersei@gmail.com" },
  { id: 3, username: "Lannister", role: "user", email: "Jaime@gmail.com" },
  { id: 4, username: "Stark", role: "user", email: "Arya@gmail.com" },
  { id: 5, username: "Targaryen", role: "user", email: "Daenerys@gmail.com" },
  { id: 6, username: "Melisandre", role: "user", email: "null@gmail.com" },
  { id: 7, username: "Clifford", role: "user", email: "Ferrara@gmail.com" },
  { id: 8, username: "Frances", role: "user", email: "Rossini@gmail.com" },
  { id: 9, username: "Roxie", role: "user", email: "Harvey@gmail.com" },
];
